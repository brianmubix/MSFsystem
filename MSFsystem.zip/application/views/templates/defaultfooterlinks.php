
<!-- 
==================================
JQuery
===================================
-->
<script src="<?= base_url() ?>assets/MDB/js/jquery-3.4.1.min.js"></script>

<!-- 
==================================
Sweet Alert
===================================
-->
<script src="<?= base_url() ?>assets/js/sweetalert.min.js"></script>



<!-- 
==================================
Material Bootstrap 4 
===================================
-->

<!-- Bootstrap tooltips -->
<script type="text/javascript" src="<?= base_url() ?>assets/MDB/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="<?= base_url() ?>assets/MDB/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="<?= base_url() ?>assets/MDB/js/mdb.min.js"></script>

<!-- 
==================================
default custom js
===================================
-->

<script src="<?= base_url() ?>assets/js/common.js?v<?= $this->config->item('code_version'); ?>" ></script>





